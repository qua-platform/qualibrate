from qualibrate_app.api.exceptions.classes.api import QApiException


class QJsonDbException(QApiException):
    pass
