from pydantic_settings import BaseSettings


class QualibrateRunnerSettings(BaseSettings):
    pass
