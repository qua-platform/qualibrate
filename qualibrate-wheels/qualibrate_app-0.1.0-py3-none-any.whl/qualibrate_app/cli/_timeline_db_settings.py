from pydantic_settings import BaseSettings


class TimelineDbSettings(BaseSettings):
    pass


class TimelineDbSettingsSetup(TimelineDbSettings):
    pass
