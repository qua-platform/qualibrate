from enum import Enum


class Outcome(Enum):
    SUCCESSFUL = "successful"
    FAILED = "failed"
