class StopInspection(Exception):
    pass
